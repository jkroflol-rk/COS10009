def main
	name_array = Array.new()

	puts("How many names: ")
  	count = gets.to_i
  	index = 0
  	while (index < count)
		puts("Enter next name: ")
    	name_array << gets.chomp
    	index += 1 # Increment index by one
  	end

	index = 0
	while (index < count)
		puts name_array[index]
    	index += 1 # Increment index by one
  	end
end

main
