
mylist = ["apple", "pear", "orange"]

puts "Original list: "
puts mylist

mylist += ["banana", "plum"]

puts "List with another list ['banana', 'plum'] added: "
puts mylist

mylist.insert(3, 'cherry')
puts "List with an item 'cherry' inserted after position 3: "
puts mylist
