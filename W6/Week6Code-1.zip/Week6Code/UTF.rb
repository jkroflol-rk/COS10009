#source: https://www.charbase.com

checkmark = "\u2713"
puts checkmark.encode('utf-8')

omega = "\u0394"
puts omega.encode('utf-8')
